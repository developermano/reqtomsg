package com.example.reqtomsg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
